﻿using Microsoft.EntityFrameworkCore;

namespace Pesto.Backend.Models
{
    public class TaskDbContext : DbContext
	{
        protected readonly IConfiguration Configuration;

        public TaskDbContext(DbContextOptions<TaskDbContext> options, IConfiguration configuration) : base(options)
		{

		}

        //protected override void OnConfiguring(DbContextOptionsBuilder options)
        //{
        //    options.UseNpgsql(Configuration.GetConnectionString("TaskDbConString"));
        //}

        public DbSet<TaskStatus> TaskStatuses { get; set; }
		public DbSet<Task> Tasks { get; set; }
	}
}