﻿using Microsoft.AspNetCore.Mvc;
using Pesto.Backend.Models;

namespace Pesto.Backend.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class TaskController : ControllerBase
    {
        private readonly ILogger<TaskController> _logger;
        private readonly TaskDbContext _taskDbContext;

        public TaskController(ILogger<TaskController> logger, TaskDbContext taskDbContext)
        {
            _logger = logger;
            _taskDbContext = taskDbContext;
        }

        [HttpGet, Route("GetAllTaskStatuses")]
        public IActionResult GetAllTaskStatuses()
        {
            return Ok(_taskDbContext.TaskStatuses.ToList());
        }

        [HttpGet, Route("GetTaskStatus/{id:int}")]
        public IActionResult GetTaskStatus(int id)
        {
            return Ok(_taskDbContext.TaskStatuses.FirstOrDefault(x => x.Id == id));
        }

        [HttpGet, Route("GetAllTasks")]
        public IActionResult GetAllTasks()
        {
            var tasks = from task in _taskDbContext.Tasks
                        join status in _taskDbContext.TaskStatuses on task.Status equals status.Id
                        orderby task.Id
                        select new { task.Id, task.Title, task.Description, status.Status };
            return Ok(tasks.ToList());
        }

        [HttpGet, Route("GetTask/{id:int}")]
        public IActionResult GetTask(int id)
        {
            return Ok(_taskDbContext.Tasks.FirstOrDefault(x => x.Id == id));
        }

        [HttpPost, Route("CreateTask")]
        public IActionResult CreateTask(Models.Task task)
        {
            if(string.IsNullOrWhiteSpace(task.Title))
            {
                return BadRequest("Title is empty.");
            }
            Models.Task newTask = new() { Title = task.Title, Description = task.Description };
            _taskDbContext.Tasks.Add(newTask);
            _taskDbContext.SaveChanges();
            return Ok(newTask);
        }

        [HttpPut, Route("UpdateTask")]
        public IActionResult UpdateTask(Models.Task task)
        {
            if (task.Id < 1)
            {
                return BadRequest("Id is invalid.");
            }
            if (string.IsNullOrWhiteSpace(task.Title))
            {
                return BadRequest("Title is empty.");
            }
            if (task.Status < 1)
            {
                return BadRequest("Status is invalid.");
            }
            _taskDbContext.Tasks.Update(task);
            _taskDbContext.SaveChanges();
            return Ok(task);
        }

        [HttpDelete, Route("DeleteTask/{id:int}")]
        public IActionResult DeleteTask(int id)
        {
            var task = _taskDbContext.Tasks.FirstOrDefault(x => x.Id == id);
            if (task == null)
            {
                return NotFound(id);
            }
            _taskDbContext.Tasks.Remove(task);
            _taskDbContext.SaveChanges();
            return Ok();
        }
    }
}