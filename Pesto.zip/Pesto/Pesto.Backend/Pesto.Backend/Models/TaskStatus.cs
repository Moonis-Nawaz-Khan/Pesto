﻿using System.ComponentModel.DataAnnotations.Schema;

namespace Pesto.Backend.Models
{
	[Table("taskstatuses")]
    public class TaskStatus
	{
		[Column("id")]
		public int Id { get; set; }

		[Column("status")]
		public string Status { get; set; }
	}
}