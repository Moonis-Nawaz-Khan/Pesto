﻿using System.ComponentModel;
using System.ComponentModel.DataAnnotations.Schema;

namespace Pesto.Backend.Models
{
    [Table("tasks")]
    public class Task
    {
        [Column("id")]
        public int Id { get; set; }

        [Column("title")]
        public string Title { get; set; }

        [Column("description")]
        public string Description { get; set; }

        [Column("status")]
        public int Status { get; set; }

        public Task()
        {
            Status = 1;
        }
    }
}