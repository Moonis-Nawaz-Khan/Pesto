"use client";
import { useState, useEffect } from 'react';
import { DataTable } from 'primereact/datatable';
import { Column } from 'primereact/column';
import { Button } from 'primereact/button';
import "/node_modules/primeflex/primeflex.css";
import "primeicons/primeicons.css";
import { Dialog } from 'primereact/dialog';
import { InputText } from 'primereact/inputtext';
import { InputTextarea } from 'primereact/inputtextarea';
import { Dropdown } from 'primereact/dropdown';
import { FilterMatchMode, FilterOperator } from 'primereact/api';

export default function Home() {
  const [dialogVisible, setDialogVisible] = useState(false);
  const [dialogMode, setDialogMode] = useState('');
  const [id, setId] = useState(0);
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const columns = [
    { field: 'title', header: 'Title' },
    { field: 'description', header: 'Description' },
    { field: 'status', header: 'Status' }
  ];
  const [filters, setFilters] = useState({
    global: { value: null, matchMode: FilterMatchMode.CONTAINS },
    title: { value: null, matchMode: FilterMatchMode.CONTAINS },
    description: { value: null, matchMode: FilterMatchMode.CONTAINS },
    status: { value: null, matchMode: FilterMatchMode.CONTAINS }
  });
  const [tasks, setTasks] = useState([]);
  const [statuses, setStatuses] = useState([]);
  const [status, setStatus] = useState('');
  const baseUrl = 'https://localhost:7211/';

  const getAllTasks = async () => {
    let result = await fetch(baseUrl + 'Task/GetAllTasks',
      {
        method: 'GET'
      });
    let body = await result.json();
    setTasks(body);
  };

  useEffect(() => {
    getAllTasks();

    (async () => {
      let result = await fetch(baseUrl + 'Task/GetAllTaskStatuses',
        {
          method: 'GET'
        });
      let body = await result.json();
      setStatuses(body.map(x => ({ name: x.status, code: x.id })));
    })();
  }, []);

  const showAddDialog = () => {
    setTitle('');
    setDescription('');
    setStatus('');
    setDialogMode('Add');
    setDialogVisible(true);
  };

  const showEditDialog = index => {
    setId(tasks[index].id);
    setTitle(tasks[index].title);
    setDescription(tasks[index].description);
    setStatus(statuses.filter(x => x.name === tasks[index].status)[0]);
    setDialogMode('Edit');
    setDialogVisible(true);
  };

  const deleteTask = index => {
    if (!confirm('Do you really want to delete this task?')) {
      return;
    }
    (async () => {
      let result = await fetch(baseUrl + 'Task/DeleteTask/' + tasks[index].id,
        {
          method: 'DELETE'
        });
      getAllTasks();
    })();
  };

  const saveTask = () => {
    if (isNullOrWhitespace(title)) {
      alert('Please enter title.');
      return;
    }
    switch (dialogMode) {
      case 'Add':
        addTask();
        break;
      case 'Edit':
        editTask();
        break;
    }
  };

  const addTask = async () => {
    await fetch(baseUrl + 'Task/CreateTask',
      {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(
          {
            title: title,
            description: description
          }
        )
      });
    setDialogVisible(false);
    getAllTasks();
  };
  const editTask = async () => {
    await fetch(baseUrl + 'Task/UpdateTask',
      {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(
          {
            id: id,
            title: title,
            description: description,
            status: status.code
          }
        )
      });
    setDialogVisible(false);
    getAllTasks();
  };

  const isNullOrWhitespace = str => {
    return str === null || str === undefined || str.trim() === '';
  };

  const header = (
    <div className="flex flex-wrap align-items-center justify-content-between gap-2">
      <span className="text-xl text-900 font-bold">Tasks</span>
      <Button icon="pi pi-plus" rounded raised tooltip='Add' tooltipOptions={{ position: 'left' }} onClick={showAddDialog} severity="success" />
    </div>
  );

  return (
    <>
      <DataTable header={header} value={tasks} tableStyle={{ minWidth: '50rem' }} globalFilterFields={['status']} filters={filters} filterDisplay="row" >
        <Column key="#" body={(rowData, column) => {
          return <>{column.rowIndex + 1}.</>;
        }} header="#" style={{ width: '3rem' }} />
        {columns.map((col, i) => (
          <Column key={col.field} field={col.field} header={col.header} filter filterField={col.field} />
        ))}
        <Column
          key="action"
          body={(rowData, column) => (
            <>
              <Button icon="pi pi-pencil" rounded raised tooltip='Edit' tooltipOptions={{ position: 'top' }} onClick={() => showEditDialog(column.rowIndex)} severity="info" />
              <Button className='ml-1' icon="pi pi-trash" rounded raised tooltip='Delete' tooltipOptions={{ position: 'top' }} onClick={() => deleteTask(column.rowIndex)} severity="danger" />
            </>
          )}
          header="Action"
          style={{ width: '9rem', textAlign: 'center' }}
        />
      </DataTable>

      <Dialog header={dialogMode} visible={dialogVisible} style={{ width: '50vw' }} onHide={() => setDialogVisible(false)}>
        <div className='grid mt-1'>
          <div className='col-12'>
            <div className='field'>
              <InputText value={title} onChange={(e) => setTitle(e.target.value)} placeholder='Title' className='w-full' />
            </div>
          </div>
          <div className='col-12'>
            <InputTextarea value={description} onChange={(e) => setDescription(e.target.value)} rows={5} cols={30} placeholder='Description' className='w-full' />
          </div>
          {
            dialogMode === 'Edit' &&
            <div className='col-12'>
              <Dropdown value={status} onChange={(e) => setStatus(e.value)} options={statuses} optionLabel="name" placeholder="Select Status" className="w-full" />
            </div>
          }
          <div className='col-12'>
            <Button icon="pi pi-save" rounded raised tooltip='Save' tooltipOptions={{ position: 'left' }} style={{ float: 'right' }} onClick={saveTask} severity={dialogMode === 'Add' ? 'success' : 'info'} />
          </div>
        </div>
      </Dialog>
    </>
  );
}
